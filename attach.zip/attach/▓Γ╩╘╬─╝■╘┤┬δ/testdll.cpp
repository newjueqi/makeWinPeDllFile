#include <iostream>
#include <windows.h>
using namespace std;

int main()
{
	typedef void(*pShowMsg)(void); 
	HINSTANCE hDLL; 
	pShowMsg ShowMeg; 
	hDLL=LoadLibrary("BinaryDll.dll"); 
	ShowMeg=(pShowMsg)GetProcAddress(hDLL,"ShowMesBox"); 
	ShowMeg(); 
	::FreeLibrary(hDLL); 
	return 0;
}
